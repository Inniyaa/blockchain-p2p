from flask import Flask, jsonify, request, render_template, redirect
from blockchain import Blockchain

app = Flask(__name__)
blockchain = Blockchain()

# Dashboard route
@app.route('/')
def index():
    return render_template('index.html', chain=blockchain.chain, node_name="Node1")

# Web form to add transaction
@app.route('/new_transaction', methods=['POST'])
def web_transaction():
    sender = request.form['sender']
    receiver = request.form['receiver']
    amount = int(request.form['amount'])

    blockchain.add_transaction(sender, receiver, amount)
    return redirect('/')

# Web button to mine block
@app.route('/mine_block', methods=['POST'])
def web_mine():
    last_block = blockchain.get_previous_block()
    proof = blockchain.proof_of_work(last_block['proof'])
    blockchain.add_transaction(sender="Network", receiver="Node1", amount=1)
    previous_hash = blockchain.hash(last_block)
    block = blockchain.create_block(proof, previous_hash)
    return redirect('/')

# Web button to sync chain
@app.route('/resolve', methods=['POST'])
def web_resolve():
    blockchain.replace_chain()
    return redirect('/')

# REST API to mine using GET
@app.route('/mine', methods=['GET'])
def mine():
    last_block = blockchain.get_previous_block()
    proof = blockchain.proof_of_work(last_block['proof'])
    blockchain.add_transaction("Network", "Node1", 1)
    previous_hash = blockchain.hash(last_block)
    block = blockchain.create_block(proof, previous_hash)
    return jsonify(block), 200

# REST API to add transaction via POST
@app.route('/transactions', methods=['POST'])
def add_transaction():
    tx = request.get_json()
    index = blockchain.add_transaction(tx['sender'], tx['receiver'], tx['amount'])
    return jsonify({'message': f'Transaction will be added to block {index}'}), 201

# REST API to get full chain
@app.route('/chain', methods=['GET'])
def get_chain():
    return jsonify({'chain': blockchain.chain, 'length': len(blockchain.chain)}), 200

# REST API to register nodes
@app.route('/nodes/register', methods=['POST'])
def register_nodes():
    values = request.get_json()
    for node in values['nodes']:
        blockchain.register_node(node)
    return jsonify({'nodes': list(blockchain.nodes)}), 200

# REST API to resolve conflicts
@app.route('/nodes/resolve', methods=['GET'])
def resolve():
    blockchain.replace_chain()
    return jsonify({'message': 'Chain updated', 'chain': blockchain.chain}), 200

# Start the app on port 5001 for Node1
if __name__ == '__main__':
    app.run(port=5001)
